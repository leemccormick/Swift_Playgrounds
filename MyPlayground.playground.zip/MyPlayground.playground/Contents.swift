import UIKit

var greeting = "Hello, playground"

extension Int {
    var toString: String? {
        return String(self)
    }
    
    var convertMoneyPennyToDollar: String {
        let newDouble = Double(self) / 100.00
        let nReturnVal = "$\(String(format: "%.2f", newDouble))"
        return nReturnVal
    }
}

let test = 52353.convertMoneyPennyToDollar
let test2 = -500
let new = test2.convertMoneyPennyToDollar
