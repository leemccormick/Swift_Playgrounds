import UIKit

var greeting = "Hello, playground"
func isValidEmail(_ email: String) -> Bool {
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

    let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailPred.evaluate(with: email)
}

let email = "h@dcvcxbxcvbcvbxci.fhgh"
isValidEmail(email)
extension String {
    func isValidEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
    }
}
email.isValidEmail()

extension String {
    var isValidEmailSwift5: Bool {
        NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: self)
    }
}

email.isValidEmailSwift5



let ssn = "12345678"
//let newSSn = ssn.replacingCharacters(in: <#T##RangeExpression#>, with: <#T##StringProtocol#>)
//let rangeSSnagain = ssn.endIndex..<ssn.index(after: ssn.startIndex)
//let rangeSSn = ssn.startIndex..<ssn.index(after: ssn.)
//print("\n\n+++++++++++ TEST  => rangeSSn : \(rangeSSn) +++++++++++ AT LINE : \(#line) +++ OF \(#function) +++ IN \(#file) +++++++++++\n\n")
//let newHideSSN = ssn.replacingCharacters(in: rangeSSn, with: "*")

let str = "testrisX"
let range = str.startIndex..<str.index(after: str.startIndex)
print(str.replacingCharacters(in: range, with: "T")) //->TestrisX

let letters = "123456789"
// Replace first three characters with a string.
let start = letters.startIndex;
let end = letters.index(letters.endIndex, offsetBy: -4);
let result = letters.replacingCharacters(in: start..<end, with: "******")
// The result.
print(result)

extension String {
    func hideTextAndShowLastCharacters(_ numberOfLastCharToShow: Int) -> String {
        let start = self.startIndex
        let end = self.index(self.endIndex, offsetBy: -numberOfLastCharToShow)
        let result = self.replacingCharacters(in: start..<end, with: "******")
        return result
    }
}

let mySSn = "987654321"
let newMySSn = mySSn.hideTextAndShowLastCharacters(4)
