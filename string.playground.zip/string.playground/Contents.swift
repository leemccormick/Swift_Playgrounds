import UIKit

var greeting = "Hello, playground"
extension Double {
    var toString: String {
        return String(self)
    }
    
    var toString2decimalPlaces: String {
        return String(format: "%.2f", self)
    }
    
//    var toString2decimalPlaces: String {
//        return String(format: "%.2f", self)
//    }
    
    func rounded(toPlaces places:Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded() / divisor
    }
    
    func returnNickelRounded() -> Double {
        var outAmt :Double = 0.0
        outAmt = ceil(self * 20) / 20
        return outAmt
    }
    
    
}


extension String {
    var isValidEmail: Bool {
        NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").evaluate(with: self)
    }
    
    var toBool: Bool {
        if self.lowercased() == "true" {
            return true
        } else {
            return false
        }
    }
    
    var strNumberToStr2DecimalPlaces: String {
        let doubleString = Double(self) ?? 0.0
        return doubleString.toString2decimalPlaces
    }
    func toDecimalWithAutoLocale() -> Decimal? {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        
        //** US,CAD,GBP formatted
        formatter.locale = Locale(identifier: "en_US")
        
        if let number = formatter.number(from: self) {
            return number.decimalValue
        }
        
        //** EUR formatted
        formatter.locale = Locale(identifier: "de_DE")
        
        if let number = formatter.number(from: self) {
            return number.decimalValue
        }
        
        return nil
    }
    
    func toDate() -> Date? {
        let formats = ["MM/dd/yyyy hh:mm:ss a",
                       "yyyy-MM-dd hh:mm:ss a",
                       "MMddyyyy",
                       "yyyyMMdd",
                       "yyyy-MM-dd'T'HH:mm:ss.SSS",
                       "MM/dd/yyyy",
                       "yyyy-MM-dd'T'HH:mm:ss.SSS",
                       "yyyy-MM-dd'T'HH:mm:ss'Z'"]
        //2021-12-22T23:12:24Z
        var nReturnValDate: Date?
        for format in formats {
            nReturnValDate = getDateFromStringFormatter(format: format)
            if nReturnValDate != nil {
                return nReturnValDate
            }
        }
        return nReturnValDate
    }
    
    func currencyFormatting() -> String {
        if let value = Double(self) {
            let formatter = NumberFormatter()
            formatter.numberStyle = .currency
            formatter.maximumFractionDigits = 2
            formatter.minimumFractionDigits = 2
            if let str = formatter.string(for: value) {
                return str
            }
        }
        return ""
    }
    
    private func getDateFromStringFormatter(format: String) -> Date? {
        let format = format
        let date: String = self
        let isoDate = date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        guard let date = dateFormatter.date(from: isoDate) else { return nil}
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour,.minute,.second], from: date)
        guard let finalDate = calendar.date(from:components) else  { return nil}
        return finalDate
    }
    
    func index(from: Int) -> Index {
        return self.index(startIndex, offsetBy: from)
    }
    
    func substring(from: Int) -> String {
        let fromIndex = index(from: from)
        return String(self[fromIndex...])
    }
    
    func substring(to: Int) -> String {
        let toIndex = index(from: to)
        return String(self[..<toIndex])
    }
    
    func substring(with r: Range<Int>) -> String {
        let startIndex = index(from: r.lowerBound)
        let endIndex = index(from: r.upperBound)
        return String(self[startIndex..<endIndex])
    }
    
    func hideTextAndShowLastCharacters(_ numberOfLastCharToShow: Int) -> String {
        let start = self.startIndex
        let end = self.index(self.endIndex, offsetBy: -numberOfLastCharToShow)
        let result = self.replacingCharacters(in: start..<end, with: "******")
        return result
    }
    
    private static var digitsPattern = UnicodeScalar("0")..."9"
    var digits: String {
        return unicodeScalars.filter { String.digitsPattern ~= $0 }.string
    }
}

extension Sequence where Iterator.Element == UnicodeScalar {
    var string: String { return String(String.UnicodeScalarView(self)) }
}

let test = "$1234"
let newDouble = Double(test.digits)
let testDate = "2021-12-22T23:12:24Z".toDate()


//test.toDoubleWithAutoLocale()

// MARK: - NOTE
/*
 let str = "Hello, playground"
 print(str.substring(from: 7))         // playground
 print(str.substring(to: 5))           // Hello
 print(str.substring(with: 7..<11))    // play
 */

