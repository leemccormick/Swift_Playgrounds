import UIKit

var greeting = "Hello, playground"




//func createNewCardNumber() {
////    var nReturnVal:  String?
////    var cardType = 0
////         var cardNumber = 27
////         var clubId = 27
//         let operatorId = 15
//    let newOperatorId = addDigit(num: operatorId, digit: 4)
//  // return newOperatorId
//}

// func addDigit(num: Int, digit: Int) -> String?{

extension Int {
    func toStringByAddZeroToFront(numberOfDigits: Int) -> String? {
        var nReturnVal:  String?
        let strNum = String(self)
        if numberOfDigits > strNum.count {
        let addedDigits = numberOfDigits - strNum.count
            var jointStr = ""
            for _ in 0..<addedDigits {
              jointStr += "0"
            }
            nReturnVal = jointStr + strNum
            return nReturnVal
        } else if numberOfDigits == 1 && strNum.count == 1 {
            
            return strNum
        } else {
            return nReturnVal
        }
    }
}

func addDigit() {
    var nReturnVal:  String?
    let strNum = String(15)
    let addedDigits = 4 - strNum.count
    
    //    var array: [String] = []
    var jointStr = ""
    for i in 0..<addedDigits {
        print("\n\n+++++++++++ TEST  => i : \(i) +++++++++++ AT LINE : \(#line) +++ OF \(#function) +++ IN \(#file) +++++++++++\n\n")
        // array.append("0")
      jointStr += "0"
    }
    print(jointStr)
    nReturnVal = jointStr + strNum
    print("\n\n+++++++++++ TEST  => nReturnVal : \(nReturnVal) +++++++++++ AT LINE : \(#line) +++ OF \(#function) +++ IN \(#file) +++++++++++\n\n")
    //  return nReturnVal
}

addDigit()

27.toStringByAddZeroToFront(numberOfDigits: 4)

func createCardNumber() -> String? {
    var nReturnVal: String?
    let cardType = 0
    let cardNumber = 27
    let siteCode = 27
    let operatorId = 15
    nReturnVal = "\(cardType.toStringByAddZeroToFront(numberOfDigits: 1))\(operatorId.toStringByAddZeroToFront(numberOfDigits: 4))\(siteCode.toStringByAddZeroToFront(numberOfDigits: 4))\(cardNumber.toStringByAddZeroToFront(numberOfDigits: 7))"
    return nReturnVal
    
}

let newCardNum = createCardNumber()
print("\n\n+++++++++++ TEST  => newCardNum : \(newCardNum) +++++++++++ AT LINE : \(#line) +++ OF \(#function) +++ IN \(#file) +++++++++++\n\n")
