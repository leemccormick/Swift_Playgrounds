import Foundation

let string1 = "www.stackoverflow.com"
let string2 = "www.stackoverflow.com"

extension String {
    func index(from: Int) -> Index {
        return self.index(startIndex, offsetBy: from)
    }
    func substring(with r: Range<Int>) -> String {
        let startIndex = index(from: r.lowerBound)
        let endIndex = index(from: r.upperBound)
        return String(self[startIndex..<endIndex])
    }
}

string1.substring(with: 0..<5)

extension Date {
    // CONVERT TO STRING
    func toUTC() -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .iso8601)
        formatter.locale = Locale(identifier: "en_CA")
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.dateFormat = "yyyy-MM-dd hh:mm:ss a"
        return formatter.string(from: self)
    }
    
    // Does not work or understand yet
    func convertToPDTTtimeZone() -> Date {
        guard let timeZone = TimeZone(abbreviation: "America/Los_Angeles") else {return Date()}
        let delta = TimeInterval(timeZone.secondsFromGMT(for: self) - TimeZone.current.secondsFromGMT(for: self))
        return addingTimeInterval(delta)
    }
    
    // Does not work or understand yet
    func convertToSpecificTimeZone(initTimeZone: TimeZone, toTimeZone: String) -> Date {
        guard let timeZone = TimeZone(abbreviation: toTimeZone) else {return Date()}
        let delta = TimeInterval(timeZone.secondsFromGMT(for: self) - initTimeZone.secondsFromGMT(for: self))
        return addingTimeInterval(delta)
    }
    
    // HERE IS WORK CHANGE TO SYSTEM "CDT" TIME
    func changeToCDTsystemTimeZone() -> Date? {
        var timeInterval: TimeInterval
        var nReturnDate: Date
        let sourceOffset = TimeZone.current.secondsFromGMT(for: self)
        guard let systemTimeZone = TimeZone(abbreviation: "CDT") else  {return nil}
            let destinationOffset = systemTimeZone.secondsFromGMT(for: self)
            timeInterval = TimeInterval(destinationOffset - sourceOffset)
            nReturnDate = Date(timeInterval: timeInterval, since: self)
        return  nReturnDate
    }
}

let newDate = Date().changeToCDTsystemTimeZone()

func changeToSystemTimeZone(_ date: Date, from: TimeZone, to: TimeZone = TimeZone.current) -> Date {
    print("date \(date)")
    let sourceOffset = from.secondsFromGMT(for: date)
    let destinationOffset = to.secondsFromGMT(for: date)
    let timeInterval = TimeInterval(destinationOffset - sourceOffset)
    return Date(timeInterval: timeInterval, since: date)
}

let myTime = "2019-11-02 02:00:00"
let dateFormatter = DateFormatter()
dateFormatter.locale = Locale(identifier: "en_US_POSIX")
dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

if let from = TimeZone(abbreviation: "CDT"),
   let to = TimeZone(abbreviation: "PDT"){
    let offsetedDate = changeToSystemTimeZone(Date(), from: from,to: to)
    print(Date(), Calendar.current.timeZone)
    print(offsetedDate, to)
}
print(Date().toUTC())

let knownTimeZoneIdentifiers = TimeZone.knownTimeZoneIdentifiers
  for tz in TimeZone.knownTimeZoneIdentifiers {
      let timeZone = TimeZone(identifier: tz)
      if let abbreviation = timeZone?.abbreviation(), let seconds = timeZone?.secondsFromGMT() {
          print ("timeZone: \(tz) \nabbreviation: \(abbreviation)\nsecondsFromGMT: \(seconds)\n")
      }
  }

// MARK: - NOTE DATE SOURCE
/*
 // https://stackoverflow.com/questions/47494222/getting-the-city-country-list-in-ios-time-zone
 
 func changeToSystemTimeZone(_ date: Date, from: TimeZone, to: TimeZone = TimeZone.current) -> Date {
     print("date \(date)")
     let sourceOffset = from.secondsFromGMT(for: date)
     let destinationOffset = to.secondsFromGMT(for: date)
     let timeInterval = TimeInterval(destinationOffset - sourceOffset)
     return Date(timeInterval: timeInterval, since: date)
 }

 let myTime = "2019-11-02 02:00:00"
 let dateFormatter = DateFormatter()
 dateFormatter.locale = Locale(identifier: "en_US_POSIX")
 dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

 if let from = TimeZone(abbreviation: "CDT"),
    let to = TimeZone(abbreviation: "PDT"){
     let offsetedDate = changeToSystemTimeZone(Date(), from: from,to: to)
     print(Date(), Calendar.current.timeZone)
     print(offsetedDate, to)
 }
 */

/*
 timeZone: America/Chicago
 abbreviation: CDT
 secondsFromGMT: -18000
 
 timeZone: America/Los_Angeles
 abbreviation: PDT
 secondsFromGMT: -25200
 */
